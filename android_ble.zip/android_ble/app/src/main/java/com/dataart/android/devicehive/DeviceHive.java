package com.dataart.android.devicehive;

/**
 * Some declarations which are intended for internal use.
 */
public class DeviceHive {
	/**
	 * Logging TAG.
	 */
	public final static String TAG = "DeviceHive";
}
