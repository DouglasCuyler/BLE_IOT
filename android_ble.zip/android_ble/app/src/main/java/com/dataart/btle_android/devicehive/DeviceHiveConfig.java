package com.dataart.btle_android.devicehive;

public final class DeviceHiveConfig {

    public static final String API_ENDPOINT = "http://playground.devicehive.com/api/rest";

}
